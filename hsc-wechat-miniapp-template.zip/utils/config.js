const host = 'https://hsc-feili.oss-cn-shanghai.aliyuncs.com'

module.exports = {
  host: host
}