
var tabBar = {
      "list": [
        {
          "title": "Home",
          "naviTitle": "Home",
          "pagePath": "/pages/home/home",
          "iconPath": "/images/homehui.png",
          "selectedIconPath": "/images/home.png"
        },
        {
          "title": "My",
          "naviTitle": "My",
          "pagePath": "/pages/myselfInfo/myselfInfo",
          "iconPath": "/images/my.png",
          "selectedIconPath": "/images/myblue.png"
        },
        {
          "title": "My",
          "naviTitle": "My",
          "show": false,
          "pagePath": "/pages/mypage/mypage",
          "iconPath": "/images/my.png",
          "selectedIconPath": "/images/myblue.png"
        }        
      ]
}
module.exports = {
  tabBarData: tabBar
}