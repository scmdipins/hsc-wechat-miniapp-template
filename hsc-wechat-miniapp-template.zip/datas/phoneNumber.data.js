var phoneLoginModal = {
  "btnText":"获取验证码",
  "btnText2":"登录/注册", 
  
  "btnDisableTextColor":"#FFFFFF",
  "btnDisableColor":"#dddedf",
  "btnEnableTextColor":"#FFFFFF",
  "btnEnableColor":"#0074bd",  

  "btnDisableTextColor2":"#FFFFFF",
  "btnDisableColor2":"#dddedf",
  "btnEnableTextColor2":"#FFFFFF",
  "btnEnableColor2":"#0074bd",  

  "privacyPolicy":"隐私政策",
  "copyText":"我已阅读并同意飞利浦APP",
  "userAgreementPath":"/pages/privacy/privacy",
  "privacyPolicyPath":"/pages/privacy/privacy",
  "loginSuccess":"/pages/mypage/mypage",

  "inputVerifyCodePath":"/pages/inputVerifyCode/inputVerifyCode"
}

module.exports = {
  phoneLoginData: phoneLoginModal
}

