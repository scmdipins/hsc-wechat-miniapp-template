var registerModal = {
      "isDisablePhoneLogin": false,
      "Topimage": "/images/philips.jpg",
      "loginImages": "/images/wechat@3x.png",
      "loginText": "微信登录",
      "loginColour": "#337fbf",
      "phoneLoginText":"手机号登录/注册",
      "phoneLoginColour":"#337fbf",
      "userAgreement":"用户协议",
      "privacyPolicy":"隐私政策",
      "copyText":"如果你的手机还没有在Philip上注册。我们将直接为您注册。一旦您注册登录，您同意我们的",
      "userAgreementPath":"/pages/privacy/privacy",
      "privacyPolicyPath":"/pages/privacy/privacy",
      "agreeWechatLoginPath":"/pages/mypage/mypage",
      "refusedWechatLoginPath":"/pages/login/login",
      "phoneLoginpath":"/pages/accountAndSecurity/accountAndSecurity",
      "showModalTitle":"用户协议与隐私政策",
      "showModalContent":"我们深知隐私对您的重要性,为了更全面地呈现我们收集和使用您个人息的相关情况,我们根据最新法律法规的要求，对隐私政策和用户协议进行了详细的修订。当您点击【同意】即表示您已充分阅读、理解并接受更新过的《隐私政策》和《用户协议》的全部内容。请花一些时间熟悉我们的隐私政策,如果您有任何问题,请随时联系我们。",
      "showModalNotAgreement":"/pages/privacy/privacy",
      "time":60
    }

module.exports = {
  registerModalData: registerModal
}