var VerifyCOdeModal = {
  "btnText2":"登录/注册", 
  "btnDisableTextColor2":"#FFFFFF",
  "btnDisableColor2":"#dddedf",
  "btnEnableTextColor2":"#FFFFFF",
  "btnEnableColor2":"#0074bd",  
  "time":30


}

module.exports = {
  VerifyCOdeData: VerifyCOdeModal
}
