var DataCollectionPageConsts = {
  labelGroup : [
    {
      "imgValue": null,
      "txtValue": "浏览历史",
      "txtColor": null,
      "urlValue": null
    },    
    {
      "imgValue": null,
      "txtValue": "使用历史",
      "txtColor": null,
      "urlValue": null
    }
  ] 
}

module.exports = {
  DataCollectionPageConsts: DataCollectionPageConsts
}