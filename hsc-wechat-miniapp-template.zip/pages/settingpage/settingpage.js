// pages/settingpage/settingpage.js
var settingpageData = require("../../datas/settingpage.data.js")

Page({

  data: {
    SettingPageConsts: settingpageData.SettingPageConsts
  },

})