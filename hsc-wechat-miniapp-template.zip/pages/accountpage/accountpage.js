// pages/accountpage/accountpage.js

var accountPageConsts = require("../../datas/accountpage.data.js")

Page({

  data: {
    AccountPageConsts: accountPageConsts.AccountPageConsts
  },

  onShow: function(){

  },  

})