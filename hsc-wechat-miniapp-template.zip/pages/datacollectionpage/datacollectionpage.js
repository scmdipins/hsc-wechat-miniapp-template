// pages/datacollectionpage/datacollectionpage.js
var pageData = require("../../datas/datacollectionpage.data.js")

Page({

  data: {
    DataCollectionPageConsts: pageData.DataCollectionPageConsts
  },

})