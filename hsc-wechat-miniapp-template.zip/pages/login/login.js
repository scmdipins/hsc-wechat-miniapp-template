// pages/login/login.js
const loginData = require("../../datas/register.data")
const hsc = getApp().hsc

Page({

  /**
   * 页面的初始数据
   */
  data: {
    registerModal: null

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const _this = this;
    _this.setData({

      registerModal: loginData.registerModalData
    })
    wx.showModal({
      title: _this.data.registerModal.showModalTitle,
      content: _this.data.registerModal.showModalContent,
      confirmText: '同意',
      cancelText: '不同意',
      success(res) {
        if (res.confirm) {
          // console.log('用户点击确定')   
        } else if (res.cancel) {
          // console.log('用户点击取消')
          wx.navigateTo({
            url: _this.data.registerModal.showModalNotAgreement,
          })
        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  getPhoneNumber(e) {
    console.log(e.detail.errMsg)
    console.log(e.detail.iv)
    console.log(e.detail.encryptedData)
  }
})